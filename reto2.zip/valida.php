<?php

if(isset($_POST['commands'])){
	Header('Location: '.$_POST['commands'].'.html');
}
?>
