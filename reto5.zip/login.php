<?php 
session_start();

$user = $_POST["user"];
$pass = $_POST["pass"];

$string = <<<XML
<users>
	<user>
		<username>admin</username>
		<password>poiu9647hy</password>
	</user>
</users>
XML;

$xml = new SimpleXMLElement($string);
$resultado = $xml->xpath("//users/user[username/text()='" . $user . "' and password/text()='" . $pass . "']");
if($resultado)
{
	$_SESSION['conectado']=1;
	Header("Location: menuPrincipal.php");
}
else
{
	header ("Location: index.php");
	exit;
}
?>