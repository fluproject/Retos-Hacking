<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body style="background-color:black">
<div align="center">
	<table width="800px" height="200px" border="0px" id="gradient-style" style="text-align:center;">
	<tbody>
		<tr>
			<td>
				<img src="jackmiamijo.png"/>  
				<form id="form1" name="form1" method="post" action="login.php">
					<br>
					<img src="user.png"/><input type="text" name="user" id="user" size="10" maxlength="10" style="color:green; background-color:black;width:160px; height: 40px; border: none; padding-top:5px; padding-left: 15px; background-image:url('textbox.png');background-repeat:no-repeat;"><br><br>
					<img src="pass.png"/><input type="password" name="pass" id="pass" size="10" maxlength="10" style="color:green; background-color:black;width:160px; height: 40px; border: none; padding-top:5px; padding-left: 15px; background-image:url('textbox.png');background-repeat:no-repeat;"><br><br>
					<input type="image" name="aceptar" src="login.png">
					<br><br>
				</form> 
			</td>
		</tr>
	</tbody>
	</table>
</div>
</body>
</html>