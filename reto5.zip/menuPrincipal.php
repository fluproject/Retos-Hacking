<?php
session_start();
if(empty($_SESSION['conectado']))
{
   header ("Location: index.php");
   exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body style="background-color:black">
<div align="right">
	<img src="autenticado.png" border="none"/>
	<img src="profile.png" border="none"/>
</div>
<br/><br/><br/><br/><br/><br/>
<div align="center">
	<img src="mision.png" border="none"/><br/>
	<a href="programa.zip"><img src="mision_download.png" border="none"/></a><br/>
	<img src="fdo.png" border="none"/>
</div>

</body>
</html>